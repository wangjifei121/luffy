import Vue from 'vue'
import Vue_x from "vuex"

Vue.use(Vue_x);

export default new Vue_x.Store({
  state: {
    show: false,
  },
});

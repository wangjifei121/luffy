<template>
  <div class="content">
    <router-view></router-view>
  </div>
</template>

<script>
  export default {
    name: "detail"
  }
</script>

<style scoped>
  .content {
    margin-top: 80px;
    width: 100%;
    height: 2000px;
  }
</style>

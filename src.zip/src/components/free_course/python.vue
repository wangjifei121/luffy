<template>
  <el-row>
    <el-col :span="8" v-for="(o, index) in 12" :key="o" :offset="index > 0 ? 2 : 2">
      <el-card>
        <img src="../../assets/imgs/4.png" class="image">
        <div style="padding: 14px;">
          <span>课程大纲</span>
          <div class="bottom clearfix">
            <time class="time">{{ currentDate }}</time>
          </div>
        </div>
      </el-card>
    </el-col>
  </el-row>
</template>

<script>
  export default {
    name: "python",
    data() {
      return {
        currentDate: new Date()
      };
    }
  }
</script>

<style scoped>
  .time {
    font-size: 13px;
    color: #999;
  }

  .bottom {
    margin-top: 13px;
    line-height: 12px;
  }

  .button {
    padding: 0;
    float: right;
  }

  .image {
    width: 100%;
    display: block;
  }

  .clearfix:before,
  .clearfix:after {
    display: table;
    content: "";
  }

  .clearfix:after {
    clear: both
  }
</style>
<style>
  .el-card{
    margin-bottom: 50px;
  }
</style>

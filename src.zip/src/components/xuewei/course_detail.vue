<template>
  <div class="show_course">
    课程详情
  </div>
</template>

<script>
  export default {
    name: "course_detail"
  }
</script>

<style scoped>
  .show_course {
    background-color: #01b4e4;
    width: 100%;
    height: 400px;
    text-align: center;
    border-radius:50%;
    font-size: 70px;
    color:#fff;
    line-height: 400px;

  }


</style>

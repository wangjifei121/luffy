<template>
  <div class="navbar" v-if="show">
    <div class="container">
      <div class="navbar-logo">
        <img src="https://www.luffycity.com/static/img/head-logo.a7cedf3.svg" alt="">
      </div>
      <div class="navbar-choice">
        <el-menu :default-active="activeIndex" class="el-menu-demo" mode="horizontal" :router="true">
          <el-menu-item v-for="(link,index) in link_list" :key="index" :index="link.path">{{link.text}}
          </el-menu-item>
        </el-menu>
      </div>
      <div class="navbar-login">
        <span @click="login_click"><router-link to="/login">登录</router-link></span>|<span>注册</span>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: "navbar",
    data() {
      return {
        activeIndex: "/",
        show: true,
        link_list: [
          {
            text: "首页",
            path: "/",
          },
          {
            text: "免费课程",
            path: "/course",
          },
          {
            text: "轻课",
            path: "/qingke",
          },
          {
            text: "学位课程",
            path: "/xuewei",
          },
          {
            text: "智能题库",
            path: "/zhineng",
          },
          {
            text: "公开课",
            path: "/gongkaike",
          },
          {
            text: "内部教材",
            path: "/neibujiaocai",
          },
          {
            text: "老男孩教育",
            path: "/oldboy",
          },
        ]
      }
    },
    methods: {
      login_click: function () {
        this.show = false
      }
    }
  }
</script>

<style scoped>

  .navbar-logo {
    float: left;
    line-height: 105px;
  }

  .navbar {
    width: 100%;
    height: 80px;
    text-align: center;
    line-height: 80px;
    position: fixed;
    z-index: 999;
    top: 0;
    background-color: #fff;
    border-bottom: lavender 1px solid;
  }

  .navbar .container {
    padding: 0 50px;
  }

  .navbar-login {
    float: right;
  }

  .el-menu {
    border-bottom: none;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .navbar .container .navbar-choice {
    display: inline-block;
  }

</style>

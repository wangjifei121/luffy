<template>
    <div><h1>这是内部教材</h1></div>
</template>

<script>
    export default {
        name: "neibujiaocai"
    }
</script>

<style scoped>
div{
   width: 100%;
   height: 400px;
   border-radius: 20%;
   background-color: cornsilk;
   text-align: center;
   line-height: 400px;
   font-size: 40px;

 }
</style>

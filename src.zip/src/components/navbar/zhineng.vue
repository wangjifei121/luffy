<template>
    <div><h1>这是智能题库</h1></div>
</template>

<script>
    export default {
        name: "zhineng"
    }
</script>

<style scoped>
 div{
   width: 100%;
   height: 400px;
   border-radius: 50%;
   background-color: #84cc39;
   text-align: center;
   line-height: 400px;
   font-size: 40px;

 }
</style>

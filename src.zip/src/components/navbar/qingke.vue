<template>
  <div id="router-view">
    <div class="light-course" >
      <div class="head">
        <p class="text1 slide" >轻课是什么？</p>
        <p class="text2 slide" >轻课是路飞学城 &amp; 老男孩教育打造的线下面授班同步网络课程，同线下面授班同期开课，报名
          <br >此课程的学员无需来线下，也可通过网络同步学习业内知名讲师的课程。
        </p>
      </div>
    </div><!--v-component--> </div>
</template>

<script>
  export default {
    name: "qingke",

  }
</script>

<style scoped>

  .light-course{
    width: 100%;
    height: 671px;
    background-image: url("../../assets/imgs/6.png");
  }
  .head{
    padding-top: 50px;
    text-align: center;
    font-size: 38px;
    color: #fff;
  }
  .head .text2{
    font-size: 20px;

  }
</style>

<template>
  <div class="course">
    <div class="top-nav">
      <ul>
        <li v-for="(item, index) in category" @click="on_click(index)" :key="index" :class='{active:current == index}'>
          {{item}}
        </li>
      </ul>
    </div>
    <div style="clear: both"></div>
    <div class="course-list">
      <!--这要循环获得-->
      <el-row :gutter="20">
        <el-col :span="6" v-for="(course,index) in courses" :key="index">
          <div class="course_box" @click="detail_click(course.id)">
            <div class="head">
              <b></b>
              <p class="course_title">{{course.title}}</p>
            </div>
            <div class="box_content">
              <p class="course_brief">{{course.desc}}</p>
              <div class="course_info">
                <span>{{course.study_num}}</span>
                &nbsp;&nbsp;
                <span>{{course.level}}</span>
                <div class="price">
                  <span style="text-decoration:line-through;">原价:￥{{course.price}}</span>
                  &nbsp;&nbsp;
                  <span style="color: red">{{course.is_free}}</span>
                </div>
              </div>
            </div>
          </div>
        </el-col>

      </el-row>
    </div>
  </div>


</template>

<script>
  export default {
    name: "course",
    data() {
      return {
        current: 0,
        my_index: "",
        category: ["全部", "Python", "Linux", "前端", "Python进阶", "UI"],
        courses: [
          {
            title: "Pycharm使用秘籍",
            desc: "PyCharm是一种Python IDE，带有一整套可以帮助用户在使用Python语言SADGASHARHARHASFHASFHARHRHA",
            study_num: 193,
            level: "初级",
            price: 99,
            is_free: "免费",
            id: 1
          },
        ]
        // course_title: "Pycharm使用秘籍",
        // course_info: "PyCharm是一种Python IDE，带有一整套可以帮助用户在使用Python语言SADGASHARHARHASFHASFHARHRHA",
        // study_num: 193,
        // study_level: "初级",
        // course_price: 99,
        // is_free: "免费",
        // course_id: 1
      }
    },
    methods: {
      on_click: function (index) {
        this.current = index;
        console.log(typeof event.target.innerText)

      },
      detail_click: function (course_id) {
        console.log(course_id);
        this.$router.push({name: "course_detail", params: {id: course_id}})
        // this.$router.push("/course_detail/1")
      }
    },
    created() {

    },
    mounted() {
      let that = this;
      this.$axios.request({
        url: "http://127.0.0.1:8000/courselist/",
        method: "get"
      }).then(function (data) {
        that.courses = data.data;
        console.log(111)
      }).catch(function (data) {
        console.log(222)
      })
    }

  }
</script>

<style scoped>
  .course {
    position: absolute;
    top: 80px;
    left: 0;
    padding-left: 40px;
    padding-right: 40px;
  }

  .top-nav ul {
    margin-top: 8px;
  }

  .top-nav ul li {
    float: left;
    margin-right: 25px;
    list-style-type: none;
    font-size: 20px;
    color: #7f7f7f;
  }

  .active {
    color: #84cc39 !important;
  }

  .course_box .head {
    height: 140px;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .head img {
    height: 140px;
    width: 288px;
  }

  .head b {
    width: 100%;
    height: 140px;
    left: 0;
    top: 0;
    opacity: .9;
    background: #56CBC4;
    position: absolute;

  }

  .course_box {
    width: 288px;
    height: 270px;
    margin-bottom: 18px;
    background-color: #fff;
    border-radius: 2px;
    box-shadow: 0 1px 2px rgba(0, 0, 0, .05);
    transition: all .2s linear;
  }

  .course-list {
    margin-top: 20px;
    margin-left: 18px;
    margin-right: 18px;
  }

  .course_title {
    color: #fff;
    position: absolute;
    font-size: 28px;

  }

  .box_content {
    color: #7f7f7f;
    font-size: 16px;
    padding: 14px;
  }

  .course_brief {
    margin-top: 5px;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
  }

  .course_info {
    font-size: 14px;
    margin-top: 26px;
  }

  .price {
    float: right;
  }

</style>

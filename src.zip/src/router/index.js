import Vue from 'vue'
import Router from 'vue-router'
import lunbo from '@/components/lunbo'
import course from '@/components/navbar/course'
import gongkaike from '@/components/navbar/gongkaike'
import neibujiaocai from '@/components/navbar/neibujiaocai'
import oldboy from '@/components/navbar/oldboy'
import qingke from '@/components/navbar/qingke'
import xuewei from '@/components/navbar/xuewei'
import zhineng from '@/components/navbar/zhineng'
import login from '@/components/login'

Vue.use(Router);

export default new Router({
  mode: "history",
  routes: [
    {
      path: "/",
      component: lunbo
    },
    {
      path: "/course",
      component: course
    },
    {
      path: "/qingke",
      component: qingke
    },
    {
      path: "/xuewei",
      component: xuewei
    },
    {
      path: "/zhineng",
      component: zhineng
    },
    {
      path: "/gongkaike",
      component: gongkaike
    },
    {
      path: "/neibujiaocai",
      component: neibujiaocai
    },
    {
      path: "/oldboy",
      component: oldboy
    },
    {
      path:"/login",
      component:login
    }
  ]
})
